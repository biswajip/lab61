package com.example.omistaja.lab61;

public class a {
    PresidentList q=PresidentList.getPresidentList();
}

